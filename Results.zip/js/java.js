//Lotto number generator
function nuumbers